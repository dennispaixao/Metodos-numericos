package bisecção;

import bisecção.*;

public class Bisecção {

    public static void main(String[] args) {
      
        double tol = 0.0001;
        double a=1;
        double b=1.5;
        int cont= 0;
        while(Math.abs(a-b)>tol){
            double x = (a+b)/2;
            if (funcao.calcula(x)*funcao.calcula(a)<0){
                b=x;
            }else{
                a=x;
            }
            cont ++;
            System.out.println(cont +" - " + x);
    }  
  
}
}