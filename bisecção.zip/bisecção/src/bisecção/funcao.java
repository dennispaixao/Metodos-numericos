/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bisecção;

/**
 *
 * @author ArteNativa
 */
public class funcao{
    
    /**
     *
     * @param x
     * @return
     */
    public static double calcula(double x){
        double _3= Math.pow(x,3);
        double _2= Math.pow(x,2);
        double _5= Math.pow(x,5);
 
        // double res = 3*_3-2*_2+4*x-1; 
        double res = 4*_5-3*_3+2*_2-4; 
        
        
         // f(x) = 4x5 – 3x3 + 2x2 – 4 
        
        return res;
    }
    
}
