
         
const recTable = ()=>{
    let rowsx = document.querySelectorAll("#x");
    let rowsy = document.querySelectorAll("#y");
    let dados =[];
    for(let j=0; j<rowsx.length;j++){
        dados.push([parseFloat(rowsx[j].textContent),parseFloat(rowsy[j].textContent)]);  
    }
    
    let sumX = dados.reduce(function(total, indice){return total + indice[0];}, 0);
    let sumY = dados.reduce(function(total, indice){return total + indice[1];}, 0);
    let sumX2 = (dados.reduce(function(total, indice){return total + indice[0]**2;}, 0).toFixed(2));
    let sumXY = (dados.reduce(function(total, indice){return total + indice[0]*indice[1];}, 0).toFixed(2));

    let D =(sumX2*dados.length-sumX*sumX).toFixed(2);
    let DA =(sumXY*dados.length-sumX*sumY).toFixed(2);
    let DB =(sumX2*sumY-sumX*sumXY).toFixed(2);
    let A =(DA/D).toFixed(2);
    let B =(DB/D).toFixed(2);
   
   document.querySelector("#resultado").textContent = "y="+A+"x*"+B;

    
}

document.querySelector("#insert").addEventListener("click",()=>{
    let tr = document.createElement("tr");
    let tdx= document.createElement("td");
    tdx.setAttribute("id","x")
    tdx.textContent = document.querySelector("#a").value;
    let tdy= document.createElement("td");
    tdy.setAttribute("id","y")
    tdy.textContent = document.querySelector("#b").value;
    tr.appendChild(tdx);
    tr.appendChild(tdy);
    document.querySelector("#tbody").appendChild(tr); 
    recTable();
    
    
});