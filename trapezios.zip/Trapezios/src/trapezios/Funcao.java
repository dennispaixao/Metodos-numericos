/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trapezios;

/**
 *
 * @author ArteNativa
 */
public class Funcao {
    
    public static double calcula(double x){
        double _2 = Math.pow(x, 2);

        return _2+4*x-3;
    }
    
}
