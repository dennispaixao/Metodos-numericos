/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trapezios;

/**
 *
 * @author ArteNativa
 */
public class Trapezios {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) { 
        double a=3;
        double b=8;
        int n=40;
        double h=(b-a)/n;    
        System.out.println(a+"----- "+Funcao.calcula(a)); 
        double somarest=0;
        double xRest= a+h;   
        while(xRest<b){      
            somarest+=Funcao.calcula(xRest);
            System.out.println(xRest+"----- "+Funcao.calcula(xRest)); 
            xRest+=h;      
        }
        System.out.println(b+"----- "+Funcao.calcula(b)); 
        //h/2*(f(a)+f(b)+2*SOMA(f(a+h):f(b-h)))
        double resultado = h/2*(Funcao.calcula(a)+Funcao.calcula(b)+2*(somarest));   
        System.out.println("Resultado: "+ resultado); 
    
    }
    
}
