/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newton;

/**
 *
 * @author alunocmc
 */
public class Newton {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        
   //  X=x0
   // Repete iter vezes
   // X=X-f(X)/f’(X)
   // Resultado=X
   double tol = 0.000001;
   double x = 0;
   int iter = 6;
   double xanterior = 1;
   
   //SE(ABS(C39-C38)<$I$5
     int cont = 0;
     //while(cont < iter){
     //while(Math.abs(funcao.calculaf(x)) > tol){
     while(Math.abs(x-xanterior) > tol){
         xanterior = x;
         x=x-funcao.calculaf(x)/funcao.calculalf(x);         
         cont++;
         
         System.out.println(cont + " - "+x);
     }   
          
    }
    
}
