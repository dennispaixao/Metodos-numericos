/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newton;

/**
 *
 * @author alunocmc
 */
public class funcao {
    
    
   public static double calculaf(double x){
    //   f(x) =  3x3 – 2x2 + 4x –1			
        double _3= Math.pow(x,3);
        double _2= Math.pow(x,2);
        double _4= Math.pow(x,4);
        double _5= Math.pow(x,5);   
        
        double res = 3*_3-2*_2+4*x-1;
        
        return res;
    }
   
    public static double calculalf(double x){
    // e f´(x) = 9x2-4x+4				
        double _3= Math.pow(x,3);
        double _2= Math.pow(x,2);
        double _4= Math.pow(x,4);
        double _5= Math.pow(x,5);   
        
        double res = 9*_2-4*x+4; 
        return res;
    }
    
}
